const o=()=>{};export{o as g};
//# sourceMappingURL=p-e1255160.js.map